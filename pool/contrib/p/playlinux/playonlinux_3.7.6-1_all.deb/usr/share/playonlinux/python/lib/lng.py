#!/usr/bin/python
import wxversion
wxversion.select("2.8")
import gettext, Variables as Variables, os
import locale, string, wx
class Lang(object):
	def __init__(self):
		languages = os.listdir('/usr/share/locale')

		langid = wx.LANGUAGE_DEFAULT
		localedir = "/usr/share/locale"
		domain = "pol"
		mylocale = wx.Locale(langid)
		mylocale.AddCatalogLookupPathPrefix(localedir)
		mylocale.AddCatalog(domain)

		mytranslation = gettext.translation(domain, localedir, [mylocale.GetCanonicalName()], fallback = True)
		mytranslation.install()



