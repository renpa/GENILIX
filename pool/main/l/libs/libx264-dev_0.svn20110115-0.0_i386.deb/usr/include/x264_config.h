#define X264_BIT_DEPTH 8
#define X264_GPL       1
