#!/usr/bin/python
import wxversion, os, getopt, sys, urllib, signal
wxversion.select("2.8")
import wx

exit()
